const canvas = document.getElementById('matrix-canvas');
const ctx = canvas.getContext('2d');
function resizeCanvas() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
window.addEventListener('resize', resizeCanvas); resizeCanvas();
const chars = "ｦｱｳｴｵｶｷｹｺｻｼｽｾｿﾀﾂﾃﾅﾆﾇﾈﾊﾋﾎﾏﾐﾑﾒﾓﾔﾕﾗﾘﾜ0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const fontSize = 16; let columns = Math.floor(canvas.width / fontSize); let drops = Array(columns).fill(1);
function drawMatrix() {
    ctx.fillStyle = "rgba(0, 5, 2, 0.1)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#00ff66"; ctx.font = `${fontSize}px monospace`;
    for (let i = 0; i < drops.length; i++) {
        const text = chars.charAt(Math.floor(Math.random() * chars.length));
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);
        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
    }
}
setInterval(drawMatrix, 35);
const inputEl = document.getElementById('terminal-input');
const logsEl = document.getElementById('terminal-logs');
inputEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        const command = inputEl.value.trim(); if (!command) return;
        appendLog(`root@aethel:~$ ${command}`, 'system'); processCommand(command.toUpperCase());
        inputEl.value = ''; logsEl.scrollTop = logsEl.scrollHeight;
    }
});
function appendLog(text, type = 'normal') {
    const div = document.createElement('div'); div.className = `log-line ${type}`; div.innerText = text; logsEl.appendChild(div);
}
function processCommand(cmd) {
    switch (cmd) {
        case 'HELP': appendLog('COMANDOS: STATUS, WAKEUP, CLEAR'); break;
        case 'STATUS': appendLog('SISTEMA OPERATIVO', 'system'); break;
        case 'WAKEUP': appendLog('Despertando...', 'system'); break;
        case 'CLEAR': logsEl.innerHTML = ''; break;
        default: appendLog('Comando desconocido', 'error'); break;
    }
}