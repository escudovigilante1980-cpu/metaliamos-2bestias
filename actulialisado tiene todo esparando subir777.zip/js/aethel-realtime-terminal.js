class AethelRealtimeTerminal {
    constructor(inputId, logsContainerId, commandEngine, core3D) {
        this.inputEl = document.getElementById(inputId);
        this.logsEl = document.getElementById(logsContainerId);
        this.cmdEngine = commandEngine;
        this.core3D = core3D;

        this.history = [];
        this.historyIndex = -1;

        this.availableCommands = [
            "SCAN", "SC", "ZOOM", "ZM", "PHI", "PH", 
            "BIFURCAR", "BF", "COLAPSAR", "CLP", "PURGAR", "PRG", "HELP"
        ];

        this.initEventListeners();
    }

    initEventListeners() {
        if (!this.inputEl) return;

        this.inputEl.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.executeCurrentInput();
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                this.navigateHistory('UP');
            } else if (e.key === 'ArrowDown') {
                e.preventDefault();
                this.navigateHistory('DOWN');
            } else if (e.key === 'Tab') {
                e.preventDefault();
                this.autocomplete();
            }
        });
    }

    executeCurrentInput() {
        const rawText = this.inputEl.value.trim();
        if (!rawText) return;

        this.history.push(rawText);
        this.historyIndex = this.history.length;

        this.appendLog(`AETHEL@PRIME:~$ ${rawText}`, 'cmd');

        const response = this.cmdEngine ? this.cmdEngine.procesar(rawText) : { status: "OK", msg: `> Ejecutado: ${rawText}` };

        const logType = response.status === 'INVALID' ? 'error' : (response.status === 'PURGED' ? 'warning' : 'info');
        
        // Multi-line support for HELP
        const lines = response.msg.split('\n');
        lines.forEach(line => this.appendLog(line, logType));

        if (this.core3D && this.core3D.setCoreStatus) {
            if (response.status === 'PURGED') {
                this.core3D.setCoreStatus('PURGE');
            } else if (response.status === 'INVALID') {
                this.core3D.setCoreStatus('CRITICAL');
            } else {
                this.core3D.setCoreStatus('NORMAL');
            }
        }

        this.inputEl.value = '';
        this.scrollToBottom();
    }

    navigateHistory(direction) {
        if (this.history.length === 0) return;

        if (direction === 'UP') {
            if (this.historyIndex > 0) this.historyIndex--;
        } else if (direction === 'DOWN') {
            if (this.historyIndex < this.history.length - 1) {
                this.historyIndex++;
            } else {
                this.historyIndex = this.history.length;
                this.inputEl.value = '';
                return;
            }
        }

        if (this.history[this.historyIndex] !== undefined) {
            this.inputEl.value = this.history[this.historyIndex];
        }
    }

    autocomplete() {
        const current = this.inputEl.value.trim().toUpperCase();
        if (!current) return;

        const match = this.availableCommands.find(cmd => cmd.startsWith(current));
        if (match) {
            this.inputEl.value = match + ' ';
        }
    }

    appendLog(message, type = 'info') {
        if (!this.logsEl) return;

        const logLine = document.createElement('div');
        logLine.className = `cli-line cli-${type}`;
        logLine.innerText = message;
        this.logsEl.appendChild(logLine);
        this.scrollToBottom();
    }

    scrollToBottom() {
        if (this.logsEl) {
            this.logsEl.scrollTop = this.logsEl.scrollHeight;
        }
    }
}

window.AethelRealtime = AethelRealtimeTerminal;
