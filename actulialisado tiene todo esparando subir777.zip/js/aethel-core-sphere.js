class AethelCentralCore {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        if (!this.container || typeof THREE === 'undefined') return;

        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(45, 1, 0.1, 1000);
        this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });

        this.init();
    }

    init() {
        const size = Math.min(this.container.clientWidth || 450, 450);

        this.renderer.setSize(size, size);
        this.renderer.setPixelRatio(window.devicePixelRatio);
        this.container.appendChild(this.renderer.domElement);

        this.camera.position.z = 6;

        // 1. NÚCLEO INTERNO LUMINOSO
        const coreGeo = new THREE.SphereGeometry(0.85, 32, 32);
        const coreMat = new THREE.MeshBasicMaterial({
            color: 0x00ffcc,
            transparent: true,
            opacity: 0.85
        });
        this.coreMesh = new THREE.Mesh(coreGeo, coreMat);
        this.scene.add(this.coreMesh);

        // 2. GEOMETRÍA EXTERNA AETHEL (Icosaedro)
        const outerGeo = new THREE.IcosahedronGeometry(1.65, 2);
        const outerMat = new THREE.MeshBasicMaterial({
            color: 0x00ff66,
            wireframe: true,
            transparent: true,
            opacity: 0.65
        });
        this.outerMesh = new THREE.Mesh(outerGeo, outerMat);
        this.scene.add(this.outerMesh);

        // 3. ANILLOS DE RESONANCIA ORBITAL
        this.rings = [];
        const ringProps = [
            { radius: 2.1, color: 0x00ffff, rotX: Math.PI / 3, rotY: 0 },
            { radius: 2.4, color: 0xff0055, rotX: -Math.PI / 4, rotY: Math.PI / 6 }
        ];

        ringProps.forEach(props => {
            const ringGeo = new THREE.TorusGeometry(props.radius, 0.012, 16, 100);
            const ringMat = new THREE.MeshBasicMaterial({
                color: props.color,
                wireframe: true,
                transparent: true,
                opacity: 0.75
            });
            const ring = new THREE.Mesh(ringGeo, ringMat);
            ring.rotation.x = props.rotX;
            ring.rotation.y = props.rotY;
            this.scene.add(ring);
            this.rings.push(ring);
        });

        this.animate();
    }

    animate() {
        requestAnimationFrame(() => this.animate());

        const time = Date.now() * 0.002;

        this.outerMesh.rotation.y += 0.004;
        this.outerMesh.rotation.x += 0.002;

        this.coreMesh.rotation.y -= 0.007;

        const scale = 1 + Math.sin(time * 2.5) * 0.08;
        this.coreMesh.scale.set(scale, scale, scale);

        this.rings.forEach((ring, idx) => {
            ring.rotation.z += 0.008 * (idx % 2 === 0 ? 1 : -1);
            ring.rotation.x += 0.004 * (idx + 1);
        });

        this.renderer.render(this.scene, this.camera);
    }

    setCoreStatus(state) {
        if (!this.coreMesh || !this.outerMesh) return;
        
        if (state === 'CRITICAL') {
            this.coreMesh.material.color.setHex(0xff2255);
            this.outerMesh.material.color.setHex(0xffaa00);
        } else if (state === 'PURGE') {
            this.coreMesh.material.color.setHex(0x00ffff);
            this.outerMesh.material.color.setHex(0xffffff);
        } else {
            this.coreMesh.material.color.setHex(0x00ffcc);
            this.outerMesh.material.color.setHex(0x00ff66);
        }
    }
}

window.AethelCoreEngine = AethelCentralCore;
