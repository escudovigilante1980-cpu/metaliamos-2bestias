class AethelI18nEngine {
    constructor(idiomaInicial = 'es') {
        this.idiomaActual = idiomaInicial;
        this.listeners = [];

        this.diccionario = {
            es: {
                SYS_TITLE: "AETHEL PRIME // CLI OPERATIVA",
                STATUS_OK: "ESTADO: OPERATIVO",
                WARN_ENERGY: "ALERTA: Fluctuación de energía en matriz",
                PURGE_EXEC: "Ejecutando purga resonante...",
                BUY_BTN: "Comprar {item} por {price} BTC",
                LOCKDOWN: "LOCKDOWN TOTAL: Rutas de escape colapsadas"
            },
            en: {
                SYS_TITLE: "AETHEL PRIME // OPERATIONAL CLI",
                STATUS_OK: "STATUS: OPERATIONAL",
                WARN_ENERGY: "WARNING: Matrix energy fluctuation",
                PURGE_EXEC: "Executing resonant purge...",
                BUY_BTN: "Purchase {item} for {price} BTC",
                LOCKDOWN: "TOTAL LOCKDOWN: Escape routes collapsed"
            },
            jp: {
                SYS_TITLE: "エーテル・プライム // CLIターミナル",
                STATUS_OK: "ステータス: 正常稼働",
                WARN_ENERGY: "警告: マトリックスエネルギーの変動",
                PURGE_EXEC: "共振パージを実行中...",
                BUY_BTN: "{price} BTCで{item}を購入",
                LOCKDOWN: "完全ロックダウン: 脱出ルート閉鎖"
            },
            ru: {
                SYS_TITLE: "СИСТЕМА AETHEL PRIME // CLI",
                STATUS_OK: "СТАТУС: РАБОТАЕТ",
                WARN_ENERGY: "ВНИМАНИЕ: Колебания энергии матрицы",
                PURGE_EXEC: "Выполнение резонансной очистки...",
                BUY_BTN: "Купить {item} за {price} BTC",
                LOCKDOWN: "ПОЛНАЯ БЛОКИРОВКА: Пути эвакуации перекрыты"
            },
            zh: {
                SYS_TITLE: "AETHEL PRIME // 终端系统",
                STATUS_OK: "状态: 正常运行",
                WARN_ENERGY: "警告: 矩阵能量波动",
                PURGE_EXEC: "正在执行共振清除...",
                BUY_BTN: "以 {price} BTC 购买 {item}",
                LOCKDOWN: "全面封锁: 逃生路线已崩溃"
            },
            cipher: {
                SYS_TITLE: "ÆTH-PRM // CLI_[0x889F]",
                STATUS_OK: "ST3: [SYS_R3ADY]",
                WARN_ENERGY: "W4RN: //FLUX_D3T3CT3D",
                PURGE_EXEC: "PRG // R3S0N4NC3_S3Q",
                BUY_BTN: "ACQ {item} :: {price}_BTC",
                LOCKDOWN: "ERR // LOCKDOWN_SYS_FAILURE"
            }
        };
    }

    t(clave, parametros = {}) {
        const langDict = this.diccionario[this.idiomaActual] || this.diccionario['es'];
        let texto = langDict[clave] || this.diccionario['es'][clave] || clave;

        Object.keys(parametros).forEach(p => {
            texto = texto.replace(new RegExp(`{${p}}`, 'g'), parametros[p]);
        });

        return texto;
    }

    setLanguage(langCode) {
        if (!this.diccionario[langCode]) return;
        this.idiomaActual = langCode;
        this.notificar();
    }

    onLanguageChange(callback) {
        this.listeners.push(callback);
    }

    notificar() {
        this.listeners.forEach(cb => cb(this.idiomaActual));
    }
}

window.AethelI18n = new AethelI18nEngine('es');
