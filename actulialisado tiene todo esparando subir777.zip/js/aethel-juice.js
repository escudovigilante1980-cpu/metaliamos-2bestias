class AethelJuiceEngine {
    constructor() {
        this.audioCtx = null;
    }

    initAudio() {
        if (!this.audioCtx) {
            const AudioCtxClass = window.AudioContext || window.webkitAudioContext;
            if (AudioCtxClass) {
                this.audioCtx = new AudioCtxClass();
            }
        }
    }

    playKeyClickSound() {
        try {
            this.initAudio();
            if (!this.audioCtx) return;

            const osc = this.audioCtx.createOscillator();
            const gain = this.audioCtx.createGain();

            const freq = 1200 + Math.random() * 400;

            osc.type = 'triangle';
            osc.frequency.setValueAtTime(freq, this.audioCtx.currentTime);
            
            gain.gain.setValueAtTime(0.015, this.audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, this.audioCtx.currentTime + 0.025);

            osc.connect(gain);
            gain.connect(this.audioCtx.destination);

            osc.start();
            osc.stop(this.audioCtx.currentTime + 0.025);
        } catch(e) {
            // Silence browser audio policy errors if not user-interacted yet
        }
    }

    triggerScreenShake(duration = 300) {
        const body = document.body;
        body.classList.add('screen-shake');
        setTimeout(() => {
            body.classList.remove('screen-shake');
        }, duration);
    }
}

window.AethelJuice = new AethelJuiceEngine();
