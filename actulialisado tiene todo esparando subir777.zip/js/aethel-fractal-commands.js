class AethelFractalCommandEngine {
    constructor(terminalRef, core3DRef) {
        this.terminal = terminalRef;
        this.core3D = core3DRef;
        
        this.profundidadActual = 1;
        this.escalaFocal = 1.0;
        this.factorPhi = 1.618033;
    }

    procesar(input) {
        const tokens = input.trim().toUpperCase().split(/\s+/);
        const cmd = tokens[0];
        const arg1 = parseFloat(tokens[1]) || 1;

        switch (cmd) {
            case "SCAN":
            case "SC":
                return this.cmdScan(arg1);

            case "ZOOM":
            case "ZM":
                return this.cmdZoom(arg1);

            case "PHI":
            case "PH":
                return this.cmdPhi(arg1);

            case "BIFURCAR":
            case "BF":
                return this.cmdBifurcar(arg1);

            case "COLAPSAR":
            case "CLP":
                return this.cmdColapsar();

            case "PURGAR":
            case "PRG":
                return this.cmdPurgar(arg1);

            case "HELP":
            case "H":
                return this.cmdHelp();

            default:
                return {
                    status: "INVALID",
                    msg: `ERR_SYNTAX: Comando '${cmd}' no reconocido. Usa 'HELP' o 'SC 1'.`
                };
        }
    }

    cmdHelp() {
        return {
            status: "OK",
            msg: `[COMANDOS FRACTALES DISPONIBLES]:\n` +
                 `• SCAN (SC) [Profundidad]  -> Escanea sub-nodos fractales.\n` +
                 `• ZOOM (ZM) [Escala]       -> Cambia enfoque de zoom (0.5x - 8x).\n` +
                 `• PHI (PH) [Fuerza]        -> Modula frecuencia con Proporción Áurea.\n` +
                 `• BIFURCAR (BF) [Ramas]    -> Divide flujo de energía.\n` +
                 `• PURGAR (PRG) [Iter]      -> Ejecuta barrido de limpieza de matriz.\n` +
                 `• COLAPSAR (CLP)           -> Resetea estado a la semilla base Z_0.`
        };
    }

    cmdScan(profundidad) {
        this.profundidadActual = Math.min(Math.max(Math.floor(profundidad), 1), 6);
        const subNodosDescubiertos = Math.pow(2, this.profundidadActual);
        
        return {
            status: "OK",
            msg: `[SCAN_FRACTAL]: Profundidad ajustada a N=${this.profundidadActual}. Sub-nodos detectados: ${subNodosDescubiertos}`
        };
    }

    cmdZoom(factor) {
        this.escalaFocal = Math.min(Math.max(factor, 0.5), 8.0);
        return {
            status: "OK",
            msg: `[ZOOM_CAMBIO]: Escala focal fijada en ${this.escalaFocal}x. Matriz re-orientada.`
        };
    }

    cmdPhi(fuerza) {
        const resonancia = (fuerza * this.factorPhi).toFixed(4);
        if (this.core3D && this.core3D.setCoreStatus) {
            this.core3D.setCoreStatus('PURGE');
        }
        return {
            status: "OK",
            msg: `[RESONANCIA_PHI]: Armónico ajustado a ${resonancia} Hz. Sincronización del núcleo al 100%.`
        };
    }

    cmdBifurcar(ramas) {
        const numRamas = Math.min(Math.max(Math.floor(ramas), 1), 4);
        const costoEnergia = numRamas * 25;
        return {
            status: "OK",
            msg: `[BIFURCACIÓN]: Flujo dividido en ${numRamas} sub-rutas (${costoEnergia} unidades consumidas).`
        };
    }

    cmdColapsar() {
        this.profundidadActual = 1;
        this.escalaFocal = 1.0;
        if (this.core3D && this.core3D.setCoreStatus) {
            this.core3D.setCoreStatus('NORMAL');
        }
        return {
            status: "OK",
            msg: `[COLAPSO_SEMILLA]: Matriz reajustada a semilla base Z_0. Entropía estabilizada.`
        };
    }

    cmdPurgar(iteraciones) {
        const iter = Math.min(Math.max(Math.floor(iteraciones), 1), 10);
        const efectividad = (iter * 12.5).toFixed(1);
        
        if (this.core3D && this.core3D.setCoreStatus) {
            this.core3D.setCoreStatus('PURGE');
        }

        if (window.AethelJuice) {
            window.AethelJuice.triggerScreenShake(400);
        }

        return {
            status: "PURGED",
            msg: `[PURGA_MANDELBROT]: ${iter} iteraciones calculadas. Limpieza de materia viscosa: ${efectividad}%.`
        };
    }
}

window.AethelCmd = AethelFractalCommandEngine;
