class AethelHackerWindowManager {
    constructor() {
        this.topZIndex = 1000;
        this.matrixActive = false;
        this.canvas = null;
        this.ctx = null;
    }

    initMatrixRain(canvasId) {
        this.canvas = document.getElementById(canvasId);
        if (!this.canvas) return;

        this.ctx = this.canvas.getContext('2d');
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;

        const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%^&*§µΔΩΨ";
        const fontSize = 14;
        const columns = Math.floor(this.canvas.width / fontSize);
        const drops = Array(columns).fill(1);

        this.matrixActive = true;

        const draw = () => {
            if (!this.matrixActive) return;

            this.ctx.fillStyle = "rgba(0, 10, 2, 0.08)";
            this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

            this.ctx.fillStyle = "#00ff66";
            this.ctx.font = `${fontSize}px monospace`;

            for (let i = 0; i < drops.length; i++) {
                const text = chars.charAt(Math.floor(Math.random() * chars.length));
                this.ctx.fillText(text, i * fontSize, drops[i] * fontSize);

                if (drops[i] * fontSize > this.canvas.height && Math.random() > 0.975) {
                    drops[i] = 0;
                }
                drops[i]++;
            }
            requestAnimationFrame(draw);
        };

        draw();

        window.addEventListener('resize', () => {
            if (this.canvas) {
                this.canvas.width = window.innerWidth;
                this.canvas.height = window.innerHeight;
            }
        });
    }

    makeDraggable(windowElement, headerElement) {
        let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;

        headerElement.onmousedown = (e) => {
            if (e.target.tagName === 'SELECT' || e.target.tagName === 'BUTTON' || e.target.tagName === 'INPUT') {
                return;
            }
            e.preventDefault();
            this.topZIndex++;
            windowElement.style.zIndex = this.topZIndex;

            pos3 = e.clientX;
            pos4 = e.clientY;

            document.onmouseup = () => {
                document.onmouseup = null;
                document.onmousemove = null;
            };

            document.onmousemove = (eMove) => {
                eMove.preventDefault();
                pos1 = pos3 - eMove.clientX;
                pos2 = pos4 - eMove.clientY;
                pos3 = eMove.clientX;
                pos4 = eMove.clientY;

                windowElement.style.top = (windowElement.offsetTop - pos2) + "px";
                windowElement.style.left = (windowElement.offsetLeft - pos1) + "px";
            };
        };
    }

    typeWriter(elementId, text, speed = 25) {
        const el = document.getElementById(elementId);
        if (!el) return;
        el.innerText = "";
        let i = 0;

        const timer = setInterval(() => {
            if (i < text.length) {
                el.innerText += text.charAt(i);
                i++;
            } else {
                clearInterval(timer);
            }
        }, speed);
    }

    triggerGlitch(element) {
        if (!element) return;
        element.classList.add('hacker-glitch');
        setTimeout(() => {
            element.classList.remove('hacker-glitch');
        }, 400);
    }
}

window.AethelWindows = new AethelHackerWindowManager();
